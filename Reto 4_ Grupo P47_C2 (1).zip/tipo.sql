CREATE TABLE `tipo` (
  `idtipo` INTEGER PRIMARY KEY,
  `nombre` VARCHAR(45) NOT NULL
  );
INSERT INTO tipo (idtipo, nombre) VALUES ('1', 'Preventivo');
INSERT INTO tipo (idtipo, nombre) VALUES ('2', 'Correctivo');
INSERT INTO tipo (idtipo, nombre) VALUES ('3', 'Interno');
INSERT INTO tipo (idtipo, nombre) VALUES ('4', 'Externo');